/* TESTING STUB ONLY — implements the cuOpt C API surface used by
 * cuopt_lp_op.cpp with a small CPU PDHG (primal-dual hybrid gradient)
 * solver, the same algorithm family as cuOpt's PDLP, so the PyTorch
 * extension's marshaling can be verified end-to-end without a GPU.
 * Slow and low-accuracy by design; NOT for production use.
 */
#include "cuopt/linear_programming/cuopt_c.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct {
  cuopt_int_t m, n, nnz, sense;
  cuopt_float_t offset;
  cuopt_float_t *c, *vals, *clb, *cub, *vlb, *vub;
  cuopt_int_t *ro, *ci;
} problem_t;

typedef struct {
  double tol;
  double time_limit;
} settings_t;

typedef struct {
  cuopt_int_t term;
  cuopt_float_t obj, solve_time;
  cuopt_float_t *x, *y, *rc;
  cuopt_int_t m, n;
} solution_t;

int8_t cuOptGetIntSize(void) { return (int8_t)sizeof(cuopt_int_t); }
int8_t cuOptGetFloatSize(void) { return (int8_t)sizeof(cuopt_float_t); }

static cuopt_float_t* dup_f(const cuopt_float_t* p, cuopt_int_t k) {
  cuopt_float_t* q = (cuopt_float_t*)malloc(sizeof(cuopt_float_t) * (k ? k : 1));
  if (p && k) memcpy(q, p, sizeof(cuopt_float_t) * k);
  return q;
}
static cuopt_int_t* dup_i(const cuopt_int_t* p, cuopt_int_t k) {
  cuopt_int_t* q = (cuopt_int_t*)malloc(sizeof(cuopt_int_t) * (k ? k : 1));
  if (p && k) memcpy(q, p, sizeof(cuopt_int_t) * k);
  return q;
}

cuopt_int_t cuOptCreateRangedProblem(
    cuopt_int_t m, cuopt_int_t n, cuopt_int_t sense, cuopt_float_t offset,
    const cuopt_float_t* c, const cuopt_int_t* ro, const cuopt_int_t* ci,
    const cuopt_float_t* vals, const cuopt_float_t* clb,
    const cuopt_float_t* cub, const cuopt_float_t* vlb,
    const cuopt_float_t* vub, const char* vtypes,
    cuOptOptimizationProblem* out) {
  if (!c || !ro || !clb || !cub || !vlb || !vub || !vtypes || !out ||
      m < 0 || n <= 0)
    return CUOPT_INVALID_ARGUMENT;
  for (cuopt_int_t j = 0; j < n; ++j)
    if (vtypes[j] != CUOPT_CONTINUOUS) return CUOPT_VALIDATION_ERROR;
  problem_t* p = (problem_t*)calloc(1, sizeof(problem_t));
  p->m = m; p->n = n; p->nnz = ro[m]; p->sense = sense; p->offset = offset;
  p->c = dup_f(c, n);
  p->ro = dup_i(ro, m + 1);
  p->ci = dup_i(ci, p->nnz);
  p->vals = dup_f(vals, p->nnz);
  p->clb = dup_f(clb, m); p->cub = dup_f(cub, m);
  p->vlb = dup_f(vlb, n); p->vub = dup_f(vub, n);
  *out = p;
  return CUOPT_SUCCESS;
}

void cuOptDestroyProblem(cuOptOptimizationProblem* pp) {
  if (!pp || !*pp) return;
  problem_t* p = (problem_t*)*pp;
  free(p->c); free(p->ro); free(p->ci); free(p->vals);
  free(p->clb); free(p->cub); free(p->vlb); free(p->vub); free(p);
  *pp = NULL;
}

cuopt_int_t cuOptCreateSolverSettings(cuOptSolverSettings* sp) {
  settings_t* s = (settings_t*)calloc(1, sizeof(settings_t));
  s->tol = 1e-8; s->time_limit = 0;
  *sp = s;
  return CUOPT_SUCCESS;
}
void cuOptDestroySolverSettings(cuOptSolverSettings* sp) {
  if (sp && *sp) { free(*sp); *sp = NULL; }
}
cuopt_int_t cuOptSetIntegerParameter(cuOptSolverSettings s, const char* k,
                                     cuopt_int_t v) {
  (void)s; (void)k; (void)v; return CUOPT_SUCCESS;
}
cuopt_int_t cuOptSetFloatParameter(cuOptSolverSettings sv, const char* k,
                                   cuopt_float_t v) {
  settings_t* s = (settings_t*)sv;
  if (!strcmp(k, CUOPT_RELATIVE_PRIMAL_TOLERANCE)) s->tol = v;
  if (!strcmp(k, CUOPT_TIME_LIMIT)) s->time_limit = v;
  return CUOPT_SUCCESS;
}

/* sparse mat-vec: y = A x and y = A^T x */
static void spmv(const problem_t* p, const double* x, double* y) {
  for (cuopt_int_t i = 0; i < p->m; ++i) {
    double s = 0;
    for (cuopt_int_t k = p->ro[i]; k < p->ro[i + 1]; ++k)
      s += p->vals[k] * x[p->ci[k]];
    y[i] = s;
  }
}
static void spmtv(const problem_t* p, const double* y, double* x) {
  for (cuopt_int_t j = 0; j < p->n; ++j) x[j] = 0;
  for (cuopt_int_t i = 0; i < p->m; ++i)
    for (cuopt_int_t k = p->ro[i]; k < p->ro[i + 1]; ++k)
      x[p->ci[k]] += p->vals[k] * y[i];
}
static double clampd(double v, double lo, double hi) {
  return v < lo ? lo : (v > hi ? hi : v);
}

/* PDHG for: minimize c'x  s.t. clb <= Ax <= cub, vlb <= x <= vub */
cuopt_int_t cuOptSolve(cuOptOptimizationProblem pp, cuOptSolverSettings sv,
                       cuOptSolution* out) {
  const problem_t* p = (const problem_t*)pp;
  const settings_t* st = (const settings_t*)sv;
  const cuopt_int_t m = p->m, n = p->n;
  clock_t t0 = clock();

  double sgn = (p->sense == CUOPT_MAXIMIZE) ? -1.0 : 1.0;
  double* c = (double*)malloc(sizeof(double) * n);
  for (cuopt_int_t j = 0; j < n; ++j) c[j] = sgn * p->c[j];

  /* ||A|| via power iteration */
  double *u = (double*)calloc(n, sizeof(double));
  double *v = (double*)calloc(m > 0 ? m : 1, sizeof(double));
  for (cuopt_int_t j = 0; j < n; ++j) u[j] = 1.0 / sqrt((double)n);
  double norm_A = 1.0;
  for (int it = 0; it < 60; ++it) {
    spmv(p, u, v);
    spmtv(p, v, u);
    double nu = 0;
    for (cuopt_int_t j = 0; j < n; ++j) nu += u[j] * u[j];
    nu = sqrt(nu);
    if (nu < 1e-30) break;
    norm_A = sqrt(nu);
    for (cuopt_int_t j = 0; j < n; ++j) u[j] /= nu;
  }
  if (norm_A < 1e-12) norm_A = 1.0;
  const double tau = 0.9 / norm_A, sigma = 0.9 / norm_A;

  double *x = (double*)calloc(n, sizeof(double));
  double *xb = (double*)malloc(sizeof(double) * n);
  double *y = (double*)calloc(m > 0 ? m : 1, sizeof(double));
  double *ax = (double*)calloc(m > 0 ? m : 1, sizeof(double));
  double *aty = (double*)calloc(n, sizeof(double));
  for (cuopt_int_t j = 0; j < n; ++j) {
    double lo = p->vlb[j] <= -CUOPT_INFINITY ? -1e6 : p->vlb[j];
    double hi = p->vub[j] >= CUOPT_INFINITY ? 1e6 : p->vub[j];
    x[j] = clampd(0.0, lo, hi);
    xb[j] = x[j];
  }

  const long max_iter = 2000000;
  const double tol = st->tol > 0 ? st->tol : 1e-8;
  cuopt_int_t term = CUOPT_TERMINATION_STATUS_ITERATION_LIMIT;

  for (long it = 0; it < max_iter; ++it) {
    /* dual: y <- prox update for indicator of [clb, cub] */
    spmv(p, xb, ax);
    int blown = 0;
    for (cuopt_int_t i = 0; i < m; ++i) {
      double yt = y[i] + sigma * ax[i];
      double proj = clampd(yt / sigma, p->clb[i], p->cub[i]);
      y[i] = yt - sigma * proj;
      if (fabs(y[i]) > 1e12) blown = 1;
    }
    /* primal */
    spmtv(p, y, aty);
    for (cuopt_int_t j = 0; j < n; ++j) {
      double xn = x[j] - tau * (c[j] + aty[j]);
      xn = clampd(xn, p->vlb[j], p->vub[j]);
      xb[j] = 2 * xn - x[j];
      x[j] = xn;
      if (fabs(x[j]) > 1e13) blown = 1;
    }
    if (blown) {
      /* crude divergence classification, PDLP-style ray heuristics */
      double ny = 0, nx = 0;
      for (cuopt_int_t i = 0; i < m; ++i) ny += y[i] * y[i];
      for (cuopt_int_t j = 0; j < n; ++j) nx += x[j] * x[j];
      term = ny > nx ? CUOPT_TERMINATION_STATUS_INFEASIBLE
                     : CUOPT_TERMINATION_STATUS_UNBOUNDED;
      break;
    }
    if (it % 200 == 0) {
      /* primal feasibility + duality-gap check */
      spmv(p, x, ax);
      double viol = 0, bscale = 1;
      for (cuopt_int_t i = 0; i < m; ++i) {
        double r = ax[i] - clampd(ax[i], p->clb[i], p->cub[i]);
        if (fabs(r) > viol) viol = fabs(r);
        double bref = fabs(p->clb[i]) < CUOPT_INFINITY ? fabs(p->clb[i])
                                                       : fabs(p->cub[i]);
        if (bref < CUOPT_INFINITY && bref > bscale) bscale = bref;
      }
      /* dual objective  d(y) = -g*(y) + inf_{l<=x<=u} (c + A^T y)^T x
         with g the indicator of [clb, cub]:
         g*(y)_i = y_i * (y_i > 0 ? cub_i : clb_i). */
      spmtv(p, y, aty);
      double pobj = 0, dobj = 0;
      int dual_ok = 1;
      for (cuopt_int_t j = 0; j < n; ++j) pobj += c[j] * x[j];
      for (cuopt_int_t i = 0; i < m; ++i) {
        double thr = 1e-7 * (1 + fabs(y[i]));
        if (y[i] > thr) {
          if (p->cub[i] < CUOPT_INFINITY) dobj -= y[i] * p->cub[i];
          else dual_ok = 0;
        } else if (y[i] < -thr) {
          if (p->clb[i] > -CUOPT_INFINITY) dobj -= y[i] * p->clb[i];
          else dual_ok = 0;
        }
      }
      for (cuopt_int_t j = 0; j < n; ++j) {
        double rcj = c[j] + aty[j];
        double thr = 1e-7 * (1 + fabs(c[j]));
        if (rcj > thr) {
          if (p->vlb[j] > -CUOPT_INFINITY) dobj += rcj * p->vlb[j];
          else dual_ok = 0;
        } else if (rcj < -thr) {
          if (p->vub[j] < CUOPT_INFINITY) dobj += rcj * p->vub[j];
          else dual_ok = 0;
        }
      }
      double gap = dual_ok ? fabs(pobj - dobj) / (1.0 + fabs(pobj)) : 1e30;
      if (viol / bscale < tol && gap < 100 * tol) {
        term = CUOPT_TERMINATION_STATUS_OPTIMAL;
        break;
      }
      /* ray detection: for infeasible LPs the dual iterate grows without
         bound while primal violation stalls; for unbounded LPs the primal
         iterate diverges along a feasible improving ray. */
      double ymax = 0, xmax = 0;
      for (cuopt_int_t i = 0; i < m; ++i)
        if (fabs(y[i]) > ymax) ymax = fabs(y[i]);
      for (cuopt_int_t j = 0; j < n; ++j)
        if (fabs(x[j]) > xmax) xmax = fabs(x[j]);
      if (viol / bscale > tol && ymax > 1e4 * (1 + bscale)) {
        term = CUOPT_TERMINATION_STATUS_INFEASIBLE;
        break;
      }
      if (xmax > 1e6 && viol / bscale < 1e-6 && pobj < -1e6) {
        term = CUOPT_TERMINATION_STATUS_UNBOUNDED;
        break;
      }
      if (st->time_limit > 0 &&
          (double)(clock() - t0) / CLOCKS_PER_SEC > st->time_limit) {
        term = CUOPT_TERMINATION_STATUS_TIME_LIMIT;
        break;
      }
    }
  }

  solution_t* s = (solution_t*)calloc(1, sizeof(solution_t));
  s->term = term;
  s->m = m; s->n = n;
  s->x = dup_f(x, n);
  s->y = (cuopt_float_t*)malloc(sizeof(cuopt_float_t) * (m ? m : 1));
  /* report duals with the LP-convention sign (lagrangian A^T y):
     our iteration's y satisfies c + A^T y = reduced cost, so flip. */
  for (cuopt_int_t i = 0; i < m; ++i) s->y[i] = -sgn * y[i];
  spmtv(p, y, aty);
  s->rc = (cuopt_float_t*)malloc(sizeof(cuopt_float_t) * n);
  for (cuopt_int_t j = 0; j < n; ++j) s->rc[j] = sgn * (c[j] + aty[j]);
  double pobj = 0;
  for (cuopt_int_t j = 0; j < n; ++j) pobj += p->c[j] * x[j];
  s->obj = pobj + p->offset;
  s->solve_time = (double)(clock() - t0) / CLOCKS_PER_SEC;
  *out = s;

  free(c); free(u); free(v); free(x); free(xb); free(y); free(ax); free(aty);
  return CUOPT_SUCCESS;
}

cuopt_int_t cuOptGetTerminationStatus(cuOptSolution sp, cuopt_int_t* t) {
  *t = ((solution_t*)sp)->term;
  return CUOPT_SUCCESS;
}
cuopt_int_t cuOptGetObjectiveValue(cuOptSolution sp, cuopt_float_t* o) {
  *o = ((solution_t*)sp)->obj;
  return CUOPT_SUCCESS;
}
cuopt_int_t cuOptGetPrimalSolution(cuOptSolution sp, cuopt_float_t* xv) {
  solution_t* s = (solution_t*)sp;
  memcpy(xv, s->x, sizeof(cuopt_float_t) * s->n);
  return CUOPT_SUCCESS;
}
cuopt_int_t cuOptGetDualSolution(cuOptSolution sp, cuopt_float_t* yv) {
  solution_t* s = (solution_t*)sp;
  memcpy(yv, s->y, sizeof(cuopt_float_t) * s->m);
  return CUOPT_SUCCESS;
}
cuopt_int_t cuOptGetReducedCosts(cuOptSolution sp, cuopt_float_t* rc) {
  solution_t* s = (solution_t*)sp;
  memcpy(rc, s->rc, sizeof(cuopt_float_t) * s->n);
  return CUOPT_SUCCESS;
}
cuopt_int_t cuOptGetSolveTime(cuOptSolution sp, cuopt_float_t* t) {
  *t = ((solution_t*)sp)->solve_time;
  return CUOPT_SUCCESS;
}
void cuOptDestroySolution(cuOptSolution* sp) {
  if (!sp || !*sp) return;
  solution_t* s = (solution_t*)*sp;
  free(s->x); free(s->y); free(s->rc); free(s);
  *sp = NULL;
}
