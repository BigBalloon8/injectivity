/* TESTING STUB ONLY — a minimal re-declaration of cuOpt's C API
 * (cuopt/linear_programming/cuopt_c.h) so the PyTorch extension can be
 * compiled and numerically exercised on machines without a GPU or cuOpt.
 * The stub library (stub_cuopt.c) implements these entry points with a
 * small CPU PDHG solver. Real deployments must build against the genuine
 * header/library from https://github.com/NVIDIA/cuopt instead.
 */
#ifndef CUOPT_C_STUB_H
#define CUOPT_C_STUB_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef int32_t cuopt_int_t;
typedef double cuopt_float_t;

typedef void* cuOptOptimizationProblem;
typedef void* cuOptSolverSettings;
typedef void* cuOptSolution;

#define CUOPT_SUCCESS 0
#define CUOPT_INVALID_ARGUMENT 1
#define CUOPT_VALIDATION_ERROR 4
#define CUOPT_RUNTIME_ERROR 6

#define CUOPT_MINIMIZE 1
#define CUOPT_MAXIMIZE (-1)
#define CUOPT_CONTINUOUS 'C'
#define CUOPT_INTEGER 'I'
#define CUOPT_INFINITY 1e30

#define CUOPT_TERMINATION_STATUS_NO_TERMINATION 0
#define CUOPT_TERMINATION_STATUS_OPTIMAL 1
#define CUOPT_TERMINATION_STATUS_INFEASIBLE 2
#define CUOPT_TERMINATION_STATUS_UNBOUNDED 3
#define CUOPT_TERMINATION_STATUS_ITERATION_LIMIT 4
#define CUOPT_TERMINATION_STATUS_TIME_LIMIT 5
#define CUOPT_TERMINATION_STATUS_NUMERICAL_ERROR 6
#define CUOPT_TERMINATION_STATUS_PRIMAL_FEASIBLE 7
#define CUOPT_TERMINATION_STATUS_FEASIBLE_FOUND 8
#define CUOPT_TERMINATION_STATUS_CONCURRENT_LIMIT 9
#define CUOPT_TERMINATION_STATUS_UNBOUNDED_OR_INFEASIBLE 10

/* parameter name constants */
#define CUOPT_ABSOLUTE_DUAL_TOLERANCE "absolute_dual_tolerance"
#define CUOPT_RELATIVE_DUAL_TOLERANCE "relative_dual_tolerance"
#define CUOPT_ABSOLUTE_PRIMAL_TOLERANCE "absolute_primal_tolerance"
#define CUOPT_RELATIVE_PRIMAL_TOLERANCE "relative_primal_tolerance"
#define CUOPT_ABSOLUTE_GAP_TOLERANCE "absolute_gap_tolerance"
#define CUOPT_RELATIVE_GAP_TOLERANCE "relative_gap_tolerance"
#define CUOPT_ITERATION_LIMIT "iteration_limit"
#define CUOPT_TIME_LIMIT "time_limit"
#define CUOPT_METHOD "method"
#define CUOPT_PDLP_SOLVER_MODE "pdlp_solver_mode"
#define CUOPT_PER_CONSTRAINT_RESIDUAL "per_constraint_residual"
#define CUOPT_LOG_TO_CONSOLE "log_to_console"
#define CUOPT_PRESOLVE "presolve"
#define CUOPT_CROSSOVER "crossover"

#define CUOPT_METHOD_CONCURRENT 0
#define CUOPT_METHOD_PDLP 1
#define CUOPT_METHOD_DUAL_SIMPLEX 2
#define CUOPT_METHOD_BARRIER 3

int8_t cuOptGetIntSize(void);
int8_t cuOptGetFloatSize(void);

cuopt_int_t cuOptCreateRangedProblem(
    cuopt_int_t num_constraints, cuopt_int_t num_variables,
    cuopt_int_t objective_sense, cuopt_float_t objective_offset,
    const cuopt_float_t* objective_coefficients,
    const cuopt_int_t* constraint_matrix_row_offsets,
    const cuopt_int_t* constraint_matrix_column_indices,
    const cuopt_float_t* constraint_matrix_coefficients,
    const cuopt_float_t* constraint_lower_bounds,
    const cuopt_float_t* constraint_upper_bounds,
    const cuopt_float_t* variable_lower_bounds,
    const cuopt_float_t* variable_upper_bounds, const char* variable_types,
    cuOptOptimizationProblem* problem_ptr);

void cuOptDestroyProblem(cuOptOptimizationProblem* problem_ptr);

cuopt_int_t cuOptCreateSolverSettings(cuOptSolverSettings* settings_ptr);
void cuOptDestroySolverSettings(cuOptSolverSettings* settings_ptr);
cuopt_int_t cuOptSetIntegerParameter(cuOptSolverSettings settings,
                                     const char* name, cuopt_int_t value);
cuopt_int_t cuOptSetFloatParameter(cuOptSolverSettings settings,
                                   const char* name, cuopt_float_t value);

cuopt_int_t cuOptSolve(cuOptOptimizationProblem problem,
                       cuOptSolverSettings settings,
                       cuOptSolution* solution_ptr);

cuopt_int_t cuOptGetTerminationStatus(cuOptSolution solution,
                                      cuopt_int_t* termination_status_ptr);
cuopt_int_t cuOptGetObjectiveValue(cuOptSolution solution,
                                   cuopt_float_t* objective_value_ptr);
cuopt_int_t cuOptGetPrimalSolution(cuOptSolution solution,
                                   cuopt_float_t* solution_values);
cuopt_int_t cuOptGetDualSolution(cuOptSolution solution,
                                 cuopt_float_t* dual_solution_ptr);
cuopt_int_t cuOptGetReducedCosts(cuOptSolution solution,
                                 cuopt_float_t* reduced_cost_ptr);
cuopt_int_t cuOptGetSolveTime(cuOptSolution solution,
                              cuopt_float_t* solve_time_ptr);
void cuOptDestroySolution(cuOptSolution* solution_ptr);

#ifdef __cplusplus
}
#endif
#endif /* CUOPT_C_STUB_H */
